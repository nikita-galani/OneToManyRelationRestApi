package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CategoryController {

	@Autowired
	private CategoryRepos repo;
	
	@RequestMapping("api/categories")
	public ResponseEntity<Object> getAllBooks()
	{
		return new ResponseEntity<Object>(repo.findAll().toString(),HttpStatus.OK);
	}
	
	@RequestMapping(value = "api/categories/{id}",method = RequestMethod.GET)
 public ResponseEntity<Object> getBook(@PathVariable("id")int id)
 {
		return new ResponseEntity<Object>(repo.findById(id),HttpStatus.OK);
 }
	
	@RequestMapping(value = "api/categories/{id}",method = RequestMethod.DELETE)
	 public ResponseEntity<Object> deleteBook(@PathVariable("id")int id)
	 {
		Category b=new Category();
		b.setId(id);
			repo.delete(b);
			return new ResponseEntity<Object>("Record Deleted...",HttpStatus.OK);
	 }
	
	@RequestMapping(value = "api/categories",method = RequestMethod.POST)
	 public ResponseEntity<Object> deleteBook(@RequestBody Category b)
	 {
		
			repo.save(b);
			return new ResponseEntity<Object>("Record Inserted...",HttpStatus.CREATED);
	 }
	
	@RequestMapping(value = "api/categories/{id}",method = RequestMethod.PUT)
	 public ResponseEntity<Object> updateBook(@PathVariable("id")int id,
			 @RequestBody Category  b)
	 {
		Category b1= repo.getById(id);
		if(b1!=null)
		{
			repo.delete(b);
			b1.setId(id);
			b1.setCategoryname(b1.getCategoryname());
		
			
			repo.save(b1);
			return new ResponseEntity<Object>("Record Updated....",HttpStatus.OK);
		}
		else
			return new ResponseEntity<Object>("Record Not FOUND....",HttpStatus.NOT_FOUND);
	 }
	

}
