package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProductController {

	@Autowired
	private ProductRepos repo;
	
	@RequestMapping("api/products")
	public ResponseEntity<Object> getAllBooks()
	{
		return new ResponseEntity<Object>(repo.findAll().toString(),HttpStatus.OK);
	}
	
	@RequestMapping(value = "api/products/{id}",method = RequestMethod.GET)
 public ResponseEntity<Object> getBook(@PathVariable("id")int id)
 {
		return new ResponseEntity<Object>(repo.findById(id),HttpStatus.OK);
 }
	
	@RequestMapping(value = "api/products/{id}",method = RequestMethod.DELETE)
	 public ResponseEntity<Object> deleteBook(@PathVariable("id")int id)
	 {
		Product b=new Product();
		b.setId(id);
			repo.delete(b);
			return new ResponseEntity<Object>("Record Deleted...",HttpStatus.OK);
	 }
	
	@RequestMapping(value = "api/products",method = RequestMethod.POST)
	 public ResponseEntity<Object> deleteBook(@RequestBody Product b)
	 {
		
			repo.save(b);
			return new ResponseEntity<Object>("Record Inserted...",HttpStatus.CREATED);
	 }
	
	@RequestMapping(value = "api/products/{id}",method = RequestMethod.PUT)
	 public ResponseEntity<Object> updateBook(@PathVariable("id")int id,
			 @RequestBody Product b)
	 {
		Product b1= repo.getById(id);
		if(b1!=null)
		{
			repo.delete(b);
			b1.setId(id);
			b1.setName(b.getName());
		
			b1.setPrice(b.getPrice());
		
			repo.save(b1);
			return new ResponseEntity<Object>("Record Updated....",HttpStatus.OK);
		}
		else
			return new ResponseEntity<Object>("Record Not FOUND....",HttpStatus.NOT_FOUND);
	 }
	

}
